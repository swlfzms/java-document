/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.gdufs.iiip.ps.crwaler;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Sarah
 */
public class ReglarExpression {

    public static String Reglar(String regex, String source) {
        String content = "";
        try {
            final List<String> list = new ArrayList<String>();
            final Pattern pa = Pattern.compile(regex);
            final Matcher ma = pa.matcher(source);
            while (ma.find()) {
                list.add(ma.group());
            }
            for (int i = 0; i < list.size(); i++) {
                content = content + list.get(i);
            }
        } catch (Exception e) {
        }
        return content;
    }

    public static TreeSet<String> Reglars(String regex, String source) {
        final TreeSet<String> list = new TreeSet<String>();
        try {
            final Pattern pa = Pattern.compile(regex);
            final Matcher ma = pa.matcher(source);
            while (ma.find()) {
                String s = ma.group();
                s = s.substring(s.lastIndexOf("detail/"), s.lastIndexOf("' t"));
                s = "http://www.cnki.net/KCMS/" + s;
               
                list.add(s);
            }
        } catch (Exception e) {
        }
        return list;
    }
    
    public static ArrayList<String> Reglarss(String regex, String source) {
        final ArrayList<String> list = new ArrayList<String>();
        try {
            final Pattern pa = Pattern.compile(regex);
            final Matcher ma = pa.matcher(source);
            while (ma.find()) {
                String s = ma.group();
                s=s.replaceAll("<.*?>", "");
                s=s.replaceAll(",", "");
                list.add(s);
            }
        } catch (Exception e) {
        }
        return list;
    }
}
