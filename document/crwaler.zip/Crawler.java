/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.gdufs.iiip.ps.crwaler;

import java.io.*;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import java.net.URI;
import java.net.URL;

/**
 *
 * @author Sarah
 */
public class Crawler {

    private String htmlSource;
    static int r = 0;
    
    private static String GetCookie()
    {
//        String cookieString = "ASP.NET_SessionId=ityoseqn1i35we55bgzjhj45;";
//        cookieString+="LID=WEEvREcwSlJHSldSdnQ1YWlTd2VUNEFkb1FHSlFqRDV5Z0JIbmkyRDlPMXBVS0pPUXdoWWtPS0FISDl4VlZ3PQ==;";
//        cookieString+="SID=111015;";
//        cookieString+="KNS_DisplayModel=;";
//        cookieString+="LID=WEEvREcwSlJHSldSdnQ1YWlTd2VUNEFkb1FHSlFqRDV5Z0JIbmkyRDlPMXBVS0pPUXdoWWtPS0FISDl4VlZ3PQ==;";
//        cookieString+="RsPerPage=20;";
//        cookieString+="FileNameS=cnki%3A;";
//        cookieString+="CurTop10KeyWord=%2c%u5e7f%u4e1c%u5916%u8bed%u5916%u8d38%u5927%u5b66;";
//        cookieString+="pgv_pvi=8779497472";
        String cookieString="RsPerPage=20; ASP.NET_SessionId=j4eqryaqoytklfbckm0wu3fd; LID=WEEvREcwSlJHSldSdnQ0Ti8wOU5sT05vRk5KU3VpVVg0S2VmWUNwQUp0VEZzeGZRTlJsRHF0T1V5bHdYcm5FPQ==; SID=111016; KNS_DisplayModel=; LID=WEEvREcwSlJHSldSdnQ0Ti8wOU5sT05vRk5KU3VpVVg0S2VmWUNwQUp0VEZzeGZRTlJsRHF0T1V5bHdYcm5FPQ==; CurTop10KeyWord=%2c%u5e7f%u4e1c%u5916%u8bed%u5916%u8d38%u5927%u5b66%2c%u300a%u725b%u6d25%u5b9e%u7528%u8bcd%u5178%u7f16%u7e82%u6307%u5357%u300b%u8bc4%u4ecb; FileNameS=cnki%3A";
        return cookieString;
    }

    public String crawlHtml(String crawlUrl) {
        //System.out.println("GET	" + crawlUrl);



        try {
            HttpClient hc = new DefaultHttpClient();
            
            URL url = new URL(crawlUrl);
            URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(), url.getQuery(), null);
            HttpGet get = new HttpGet(uri);
            
            get.setHeader("Accept",
                    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            get.setHeader("Accept-Charset", "GBK,utf-8;q=0.7,*;q=0.3");
            get.setHeader("Accept-Encoding", "deflate");
            get.setHeader("Accept-Language",
                    "zh-CN,zh;q=0.8");
            get.setHeader("Cache-Control", "max-age=0");
//            get.setHeader("Content-Type", "application/x-www-form-urlencoded");
            get.setHeader("Cookie", GetCookie());
            get.setHeader("Connection", "keep-alive");
//            get.setHeader("Host", "epub.cnki.net");
//            get.setHeader("Referer", "http://lib.gdufs.edu.cn/erinfo.php?eid=6");
            get.setHeader("User-Agent",
                    "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/535.7 (KHTML, like Gecko) Chrome/16.0.912.63 Safari/535.7");
            HttpResponse response = hc.execute(get);
            HttpEntity entity = response.getEntity();
            final StringBuffer sb = new StringBuffer();
            InputStreamReader isr = new InputStreamReader(entity.getContent(),
                    "UTF-8");
            final BufferedReader br = new BufferedReader(isr);
            String temp = null;
            while ((temp = br.readLine()) != null) {
                sb.append(temp);
            }
            br.close();
            isr.close();
            htmlSource = sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return htmlSource;
    }

    public String getHtmlSource() {
        return htmlSource;
    }

    public void setHtmlSource(String htmlSource) {
        this.htmlSource = htmlSource;
    }

    public static void main(String[] a) throws IOException {
        Crawler c = new Crawler();
        String r = c.crawlHtml("http://www.cnki.net/kcms/detail/44.1124.D.20130104.1733.013.html?uid=WEEvREcwSlJHSldSdnQ0S3orenRvZ0FpcVZBbFFYSnhlSEI1SVNZanlRTVFjWWFBa29HOVNRbDJJL2xHUFNzPQ==");
        System.out.println(r);
          
//        BufferedWriter bw = new BufferedWriter(new FileWriter(new File("C:\\Documents and Settings\\Sarah\\桌面\\c.html")));
//        bw.write(r);
//        bw.flush();
//        bw.close();
    }
}