/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cn.edu.gdufs.iiip.ps.crwaler;

import com.sun.org.apache.bcel.internal.generic.ARRAYLENGTH;
import java.util.ArrayList;
import java.util.TreeSet;

/**
 *
 * @author Sarah
 */
public class Extractor {

    public TreeSet<String> extractPaperLink(String source) {
        TreeSet<String> pllist = new TreeSet<String>();
        String regex = "/kns55/detail.*?target='_blank'";
        pllist = ReglarExpression.Reglars(regex, source);
        return pllist;
    }

    public String extractNum(String source) {
        String regex = "找到.*?条结果";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll(",", "");
        result = result.replaceAll("&nbsp", "");
        result = result.replaceAll(";", "");
        result = result.substring(2, result.length() / 2 - 3);
        return result;
    }

    public String extractCTitle(String source) {
        String regex = "<span id=\"chTitle\">.*?</span>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("<.*?>", "");
        return result;
    }

    public String extractETitle(String source) {
        String regex = "<span id=\"enTitle\">.*?</span>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        result = result.replaceAll("[(].*?...", "");
        return result;
    }

    public ArrayList<String> extractCName(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【作者】.*?</p>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        result = result.replaceAll("[(].*?...", "");
        String[] temp;
        try {
            temp = result.split("；");

            if (temp.length > 0) {
                for (String s : temp) {
                    if (s.trim().length() > 1) {
                        nl.add(s.trim());
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        try {
            temp = result.split(";");

            if (temp.length > 0) {
                for (String s : temp) {
                    if (s.trim().length() > 1) {
                        nl.add(s.trim());
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result.trim());
        return nl;
    }

    public ArrayList<String> extractEName(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【Author】.*?<p>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        result = result.replaceAll("[(].*?...", "");
        result = result.replaceAll("[1-9]", "");
        try {
            String[] temp = result.split(",");

            if (temp.length > 0) {
                for (String s : temp) {
                    if (s.trim().length() > 1) {
                        nl.add(s.trim());
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result.trim());
        return nl;
    }

    public ArrayList<String> extractUnit(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【机构】.*?</p>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        result = result.replaceAll("（.*?）", "");
        result = result.replaceAll("（.*?...", "");
        //result = result.replaceAll("广东外语外贸大学", "");
        if (result.indexOf("思科信息学院") == -1) {
            result = result.replaceAll("信息学院", "思科信息学院");
        }
        try {
            String[] temp = result.split("；");
            if (temp.length > 0) {
                for (String s : temp) {
                    s = s.trim();
                    s = s.replaceAll(" ^/[0-9].*?[0-9]$", "");
                    s = s.replaceAll("^/[0-9].*?[0-9]$", "");
                    if (s.length() > 1) {
                        nl.add(s);
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result);
        return nl;
    }

    public ArrayList<String> extractOrigin(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "GetInfo[(].*?'[)]";
        String result = ReglarExpression.Reglar(regex, source);
        System.out.println(result);
        try {
            result = result.substring(result.indexOf("(") + 1, result.lastIndexOf(")"));
            String[] temp = result.split(",");
            if (temp.length > 0) {
                for (String s : temp) {
                    s = s.trim();
                    s = s.replaceAll("'", "");
                    if (s.length() > 1) {
                        nl.add(s.trim());
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result);
        return nl;
    }

    public ArrayList<String> extractCKeyWord(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【关键词】.*?<div class=\"keywords int5\">";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        try {
            String[] temp = result.split("；");
            for (String s : temp) {
                s = s.trim();
                if (s.length() > 1) {
                    nl.add(s);
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result);
        return nl;
    }

    public ArrayList<String> extractEKeyWord(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【Key words】.*?<div class=\"keywords int5\">";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        try {
            String[] temp = result.split("；");
            for (String s : temp) {
                s = s.trim();
                if (s.length() > 1) {
                    nl.add(s);
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result);
        return nl;
    }

    public String extractCSummary(String source) {
        String regex = "【摘要】.*?</span>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        return result.trim();
    }

    public String extractESummary(String source) {
        String regex = "【Abstract】.*?</span>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        return result.trim();
    }

    public ArrayList<String> extractFund(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【基金】.*?</div>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("<.*?>", "");
        result = result.replaceAll("【.*?】", "");
        try {
            String[] temp = result.split(";");
            for (String s : temp) {
                s = s.trim();
                if (s.length() > 1) {
                    nl.add(s);
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result);
        return nl;
    }

    public ArrayList<String> extractProject(ArrayList<String> nl) {
        ArrayList<String> pl = new ArrayList<String>();
        for (String s : nl) {
            ArrayList<String> spl1 = new ArrayList<String>();
            ArrayList<String> spl2 = new ArrayList<String>();
            try {
                String r = "[(].*?[)]";
                spl1 = ReglarExpression.Reglarss(r, s);
                r = "[（].*?[）]";
                spl2 = ReglarExpression.Reglarss(r, s);
                for (String ss : spl1) {
                    ss = ss.replaceAll("[(]", "");
                    ss = ss.replaceAll("[)]", "");
                    ss = ss.replaceAll(".*?:", "");
                    ss = ss.replaceAll(".*?：", "");
                    pl.add(ss);
                }
                for (String ss : spl2) {
                    ss = ss.replaceAll("[（]", "");
                    ss = ss.replaceAll("[）]", "");
                    ss = ss.replaceAll(".*?:", "");
                    ss = ss.replaceAll(".*?：", "");
                    pl.add(ss);
                }
            } catch (Exception e) {
            }
        }
        return pl;
    }

    public ArrayList<String> extractField(String source) {
        ArrayList<String> nl = new ArrayList<String>();
        String regex = "【分类号】.*?</li>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");
        try {
            String[] temp = result.split(";");

            if (temp.length > 0) {
                for (String s : temp) {
                    if (s.length() > 1) {
                        nl.add(s.trim());
                    }
                }
            }
            return nl;
        } catch (Exception e) {
        }
        nl.add(result.trim());
        return nl;
    }

    public String extractCocitation(String source) {

        String regex = "【被引频次】.*?</li>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");

        return result;
    }

    public String extractDownload(String source) {

        String regex = "【下载频次】.*?</li>";
        String result = ReglarExpression.Reglar(regex, source);
        result = result.replaceAll("[(].*?[)]", "");
        result = result.replaceAll("【.*?】", "");
        result = result.replaceAll("<.*?>", "");

        return result;
    }
    public String extractDownloadLink(String source){
        String regex = "<b>CAJ下载</b>.*?<b>PDF下载</b>";
        String result = ReglarExpression.Reglar(regex, source);
        try{            
            result=result.substring(result.lastIndexOf("download.aspx?"), result.lastIndexOf("\""));            
            System.out.println(result);
            result=result.replaceAll("&amp;", "&");
            result=result.replaceAll("&#xA; ", "");
            result=result.replaceAll(" ", "");
            result="http://www.cnki.net/kcms/"+result;
        }catch(Exception e){
            
        }
        return result;
    }    
    
    public String zhaiyao(String source){
       
        String regex = "【摘要】.*?【关键词】";
        String result = ReglarExpression.Reglar(regex, source);
        try{
            result = result.substring(result.indexOf("<span id"),result.indexOf("</span>"));   
            result = result.substring(result.indexOf(">")+1,result.length());
        }catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    public String bowen(String source){
        String regex = "<div class=\"tip2\">.*?<div class=\"pmst\">";
        String result = ReglarExpression.Reglar(regex, source);
        try{
            result = result.substring(result.indexOf("href=")+6, result.indexOf(">微博")-1);
            result = "http://weibo.cn"+result;
            result = result.replaceAll("amp;","");
        }catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    public static void main(String[] q) {
        Extractor e = new Extractor();
        Crawler c = new Crawler();
//        int i=2;
        //String r = c.crawlHtml("http://www.cnki.net/kcms/detail/44.1446.F.20121207.1721.004.html?uid=WEEvREcwSlJHSldSdnQ1WWFsMXh4Z3ROa1d6cU02M3BJajl1RVNPSW9Qalhxb0VUbExKMWpCc1FYVmxlb244PQ==");
        String r = c.crawlHtml("http://weibo.cn/?gsid=4KWx83021QS1W0HVzDxotam0S8i&vt=4");
        System.out.println(e.bowen(r));
//        TreeSet<String> l=e.extractPaperLink(r);
//        for(String s:l){
//            System.out.println(s);
//        }
        //System.out.println(e.zhaiyao(r));
//        System.out.println(e.extractDownloadLink(r));
//        System.out.println(e.extractNum(r));
    }
}
